'use client';

/**
 * app/admin/canonical-matches/page.tsx
 *
 * Review queue for cross-vendor product matches.
 * Access via /admin/canonical-matches?token=YOUR_ADMIN_SECRET
 *
 * Self-contained light theme — overrides the site's global dark mode /
 * uppercase text-transform so this stays readable regardless of global CSS.
 */

import { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'next/navigation';

interface FitmentRange {
  model_code: string;
  year_min: number;
  year_max: number;
  cnt: number;
}

interface ProductSide {
  id: number;
  name: string;
  source_vendor: string;
  internal_sku: string;
  vendor_sku: string | null;
  brand_part: string | null;
  computed_price: number;
  image_url: string | null;
  display_category: string;
  display_subcategory: string | null;
  fits_all: boolean;
}

interface Proposal {
  id: number;
  match_reason: string;
  match_score: number;
  shared_oem_number: string;
  status: string;
  a_id: number; a_name: string; a_vendor: string; a_sku: string;
  a_vendor_sku: string | null; a_brand_part: string | null; a_fits_all: boolean;
  a_price: number; a_image: string | null; a_category: string; a_subcategory: string | null;
  a_canonical_sku: string;
  b_id: number; b_name: string; b_vendor: string; b_sku: string;
  b_vendor_sku: string | null; b_brand_part: string | null; b_fits_all: boolean;
  b_price: number; b_image: string | null; b_category: string; b_subcategory: string | null;
  b_canonical_sku: string;
}

const VENDOR_COLORS: Record<string, string> = {
  PU:    '#2E6FB8',
  WPS:   '#1E8A6B',
  VTWIN: '#C98A2E',
};

function fitmentLabel(ranges: FitmentRange[] | undefined): string {
  if (!ranges || ranges.length === 0) return 'No fitment data';
  const parts = ranges.map(r => {
    const yr = r.year_min === r.year_max ? `'${String(r.year_min).slice(-2)}` : `'${String(r.year_min).slice(-2)}–'${String(r.year_max).slice(-2)}`;
    return `${r.model_code} ${yr}`;
  });
  if (parts.length <= 3) return parts.join(', ');
  return `${parts.slice(0, 3).join(', ')} (+${parts.length - 3} more)`;
}

function overallYearRange(ranges: FitmentRange[] | undefined): string | null {
  if (!ranges || ranges.length === 0) return null;
  const min = Math.min(...ranges.map(r => r.year_min));
  const max = Math.max(...ranges.map(r => r.year_max));
  return `${min}–${max}`;
}

export default function CanonicalMatchesPage() {
  const params = useSearchParams();
  const token  = params.get('token') ?? '';

  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [counts, setCounts]       = useState<Record<string, number>>({});
  const [fitment, setFitment]     = useState<Record<number, FitmentRange[]>>({});
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState<string | null>(null);
  const [busyGroups, setBusyGroups] = useState<Set<string>>(new Set());
  const [syncMsgs, setSyncMsgs]   = useState<Record<string, string>>({});
  const [appliedMsg, setAppliedMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/canonical-matches?token=${encodeURIComponent(token)}&status=pending&limit=200`);
      const data = await res.json();
      if (data.error) {
        setError(data.error);
      } else {
        setProposals(data.proposals);
        setCounts(data.counts ?? {});
        setFitment(data.fitment ?? {});
        setError(null);
      }
    } catch (e) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  if (!token) {
    return (
      <div style={{ padding: 40, fontFamily: 'monospace', background: '#fff', color: '#1a1a1a', minHeight: '100vh' }}>
        Missing ?token= in URL.
      </div>
    );
  }

  // Group proposals by shared_oem_number
  const groups = new Map<string, Proposal[]>();
  for (const p of proposals) {
    const key = p.shared_oem_number;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(p);
  }

  async function bulkAction(oem: string, action: 'confirm' | 'reject') {
    setBusyGroups(prev => new Set(prev).add(oem));
    try {
      await fetch('/api/admin/canonical-matches/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, shared_oem_number: oem, action }),
      });
      setProposals(prev => prev.filter(p => p.shared_oem_number !== oem));
    } finally {
      setBusyGroups(prev => {
        const next = new Set(prev);
        next.delete(oem);
        return next;
      });
    }
  }

  async function syncFitment(oem: string, productIds: number[]) {
    setSyncMsgs(prev => ({ ...prev, [oem]: 'Syncing...' }));
    try {
      const res = await fetch('/api/admin/canonical-matches/sync-fitment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, product_ids: productIds }),
      });
      const data = await res.json();
      if (data.error) {
        setSyncMsgs(prev => ({ ...prev, [oem]: `Error: ${data.error}` }));
        return;
      }
      if (data.total_added === 0) {
        setSyncMsgs(prev => ({ ...prev, [oem]: 'Already in sync — no changes needed' }));
      } else {
        setSyncMsgs(prev => ({ ...prev, [oem]: `Added ${data.total_added} fitment rows across ${productIds.length} products` }));
      }
      load();
    } catch (e) {
      setSyncMsgs(prev => ({ ...prev, [oem]: `Error: ${String(e)}` }));
    }
  }

  async function applyMerges() {
    setAppliedMsg('Applying...');
    const res = await fetch('/api/admin/canonical-matches/apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token }),
    });
    const data = await res.json();
    setAppliedMsg(`Merged ${data.merged} of ${data.total_confirmed} confirmed proposals.${data.errors?.length ? ` ${data.errors.length} errors.` : ''}`);
    load();
  }

  return (
    <div
      style={{
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        background: '#ffffff',
        color: '#1a1a1a',
        textTransform: 'none',
        letterSpacing: 'normal',
        minHeight: '100vh',
        WebkitFontSmoothing: 'antialiased',
      }}
    >
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '28px 24px 80px' }}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6, flexWrap: 'wrap', gap: 10 }}>
          <h1 style={{ fontSize: 24, fontWeight: 700, margin: 0, color: '#1a1a1a', textTransform: 'none' }}>
            Canonical Match Review
          </h1>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <span style={{ fontSize: 13, color: '#555' }}>
              pending <b>{counts.pending ?? 0}</b> · confirmed <b>{counts.confirmed ?? 0}</b> · applied <b>{counts.applied ?? 0}</b> · rejected <b>{counts.rejected ?? 0}</b>
            </span>
            <button
              onClick={applyMerges}
              style={{
                background: '#c9a84c', border: 'none', color: '#1a1306',
                fontWeight: 700, fontSize: 13, padding: '9px 16px',
                borderRadius: 6, cursor: 'pointer', textTransform: 'none',
              }}
            >
              Apply confirmed merges
            </button>
          </div>
        </div>

        {appliedMsg && (
          <div style={{ fontSize: 13, color: '#1E8A6B', marginBottom: 10, fontWeight: 600 }}>{appliedMsg}</div>
        )}

        <p style={{ fontSize: 13, color: '#666', marginTop: 0, marginBottom: 24, textTransform: 'none' }}>
          Grouped by shared OEM number — <b>{groups.size}</b> groups, <b>{proposals.length}</b> pairs.
          Confirming a group queues the merge — click &quot;Apply confirmed merges&quot; to execute.
          <br />
          <b>Sync fitment</b> copies the combined year/model coverage to every vendor listing in the group, even if you reject the canonical merge.
        </p>

        {loading && <div style={{ color: '#666' }}>Loading...</div>}
        {error && <div style={{ color: '#c0392b', fontWeight: 600 }}>{error}</div>}

        {!loading && groups.size === 0 && (
          <div style={{ padding: 48, textAlign: 'center', color: '#999', border: '1px dashed #ccc', borderRadius: 10 }}>
            No pending proposals. {counts.applied ? `${counts.applied} already applied.` : ''}
          </div>
        )}

        {[...groups.entries()].map(([oem, group]) => {
          const productsMap = new Map<number, ProductSide>();
          for (const p of group) {
            productsMap.set(p.a_id, {
              id: p.a_id, name: p.a_name, source_vendor: p.a_vendor, internal_sku: p.a_sku,
              vendor_sku: p.a_vendor_sku, brand_part: p.a_brand_part, fits_all: p.a_fits_all,
              computed_price: p.a_price, image_url: p.a_image, display_category: p.a_category,
              display_subcategory: p.a_subcategory,
            });
            productsMap.set(p.b_id, {
              id: p.b_id, name: p.b_name, source_vendor: p.b_vendor, internal_sku: p.b_sku,
              vendor_sku: p.b_vendor_sku, brand_part: p.b_brand_part, fits_all: p.b_fits_all,
              computed_price: p.b_price, image_url: p.b_image, display_category: p.b_category,
              display_subcategory: p.b_subcategory,
            });
          }
          const products = [...productsMap.values()].sort((a, b) => a.source_vendor.localeCompare(b.source_vendor));
          const productIds = products.map(p => p.id);
          const isBusy = busyGroups.has(oem);
          const syncMsg = syncMsgs[oem];

          const fitmentSets = products.map(p => overallYearRange(fitment[p.id]));
          const distinctRanges = new Set(fitmentSets.filter(Boolean));
          const fitmentMismatch = distinctRanges.size > 1;

          return (
            <div key={oem} style={{
              border: '1px solid #ddd8cc', borderRadius: 10, marginBottom: 16, overflow: 'hidden',
              background: '#fff',
            }}>
              <div style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '12px 16px', background: '#faf8f3', borderBottom: '1px solid #ddd8cc',
                flexWrap: 'wrap', gap: 8,
              }}>
                <div style={{ fontSize: 13, color: '#555', textTransform: 'none' }}>
                  OEM <span style={{ fontFamily: 'monospace', fontWeight: 700, color: '#1a1a1a', fontSize: 14 }}>{oem}</span>
                  {' · '}{products.length} vendors · score {group[0].match_score}
                  {fitmentMismatch && (
                    <span style={{
                      marginLeft: 10, fontSize: 11, fontWeight: 700, color: '#9a5a0c',
                      background: '#fbe8cf', padding: '2px 8px', borderRadius: 10,
                    }}>
                      ⚠ fitment differs
                    </span>
                  )}
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                  {syncMsg && (
                    <span style={{ fontSize: 12, color: syncMsg.startsWith('Error') ? '#c0392b' : '#1E8A6B', fontWeight: 600 }}>
                      {syncMsg}
                    </span>
                  )}
                  <button
                    onClick={() => syncFitment(oem, productIds)}
                    style={{
                      fontSize: 12, padding: '6px 12px', borderRadius: 5,
                      border: '1px solid #2E6FB8', background: '#e8f1fb', color: '#1d4f87',
                      fontWeight: 600, cursor: 'pointer', textTransform: 'none',
                    }}
                  >
                    Sync fitment ↔
                  </button>
                  <button
                    disabled={isBusy}
                    onClick={() => bulkAction(oem, 'reject')}
                    style={{
                      fontSize: 12, padding: '6px 12px', borderRadius: 5,
                      border: '1px solid #ddd', background: '#fff', color: '#993C1D',
                      cursor: isBusy ? 'default' : 'pointer', opacity: isBusy ? 0.5 : 1, textTransform: 'none',
                    }}
                  >
                    Reject all
                  </button>
                  <button
                    disabled={isBusy}
                    onClick={() => bulkAction(oem, 'confirm')}
                    style={{
                      fontSize: 12, padding: '6px 12px', borderRadius: 5,
                      border: '1px solid #3B6D11', background: '#e6f4d9', color: '#3B6D11',
                      fontWeight: 700, cursor: isBusy ? 'default' : 'pointer', opacity: isBusy ? 0.5 : 1, textTransform: 'none',
                    }}
                  >
                    Confirm all ({group.length})
                  </button>
                </div>
              </div>

              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, padding: 14 }}>
                {products.map(p => {
                  const ranges = fitment[p.id];
                  return (
                    <div key={p.id} style={{
                      display: 'flex', gap: 12, alignItems: 'flex-start',
                      border: '1px solid #eee', borderRadius: 8, padding: 12,
                      flex: '1 1 320px', minWidth: 300, background: '#fcfbf8',
                    }}>
                      {p.image_url ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={p.image_url} alt="" style={{ width: 56, height: 56, objectFit: 'contain', borderRadius: 4, background: '#fff', border: '1px solid #eee', flexShrink: 0 }} />
                      ) : (
                        <div style={{ width: 56, height: 56, background: '#f0eee8', borderRadius: 4, flexShrink: 0 }} />
                      )}
                      <div style={{ minWidth: 0, flex: 1 }}>
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4, flexWrap: 'wrap' }}>
                          <span style={{
                            fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 10,
                            color: '#fff', background: VENDOR_COLORS[p.source_vendor] ?? '#888',
                            textTransform: 'uppercase', letterSpacing: '0.04em',
                          }}>
                            {p.source_vendor}
                          </span>
                          <span style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a' }}>${Number(p.computed_price).toFixed(2)}</span>
                          {p.fits_all && (
                            <span style={{ fontSize: 10, fontWeight: 700, color: '#1d4f87', background: '#e8f1fb', padding: '2px 7px', borderRadius: 10 }}>
                              UNIVERSAL
                            </span>
                          )}
                        </div>
                        <div style={{ fontSize: 14, lineHeight: 1.35, color: '#1a1a1a', marginBottom: 4, textTransform: 'none' }}>
                          {p.name}
                        </div>
                        <div style={{ fontSize: 12, color: '#888', display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 4 }}>
                          {p.vendor_sku && (
                            <span><span style={{ color: '#bbb' }}>vendor#</span> <span style={{ fontFamily: 'monospace', color: '#555', fontWeight: 600 }}>{p.vendor_sku}</span></span>
                          )}
                          {p.brand_part && p.brand_part !== p.vendor_sku && (
                            <span><span style={{ color: '#bbb' }}>brand_part_number (raw)</span> <span style={{ fontFamily: 'monospace', color: '#c0392b', fontWeight: 600 }}>{p.brand_part}</span></span>
                          )}
                          <span style={{ fontFamily: 'monospace', color: '#aaa' }}>{p.internal_sku}</span>
                        </div>
                        <div style={{ fontSize: 12, color: '#999', marginBottom: 6, textTransform: 'none' }}>
                          {p.display_category}{p.display_subcategory ? ` / ${p.display_subcategory}` : ''}
                        </div>
                        <div style={{
                          fontSize: 12, color: ranges ? '#3B6D11' : '#aa6c2c',
                          background: ranges ? '#eef7e6' : '#fbf1e3',
                          border: `1px solid ${ranges ? '#cfe8bd' : '#f3ddbe'}`,
                          borderRadius: 6, padding: '4px 8px', textTransform: 'none',
                        }}>
                          {p.fits_all ? 'Fits all models' : fitmentLabel(ranges)}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
